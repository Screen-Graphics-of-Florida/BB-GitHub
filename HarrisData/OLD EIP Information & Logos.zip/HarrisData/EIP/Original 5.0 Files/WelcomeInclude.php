<?php

$sessionDateFormat=SessionDate($profileHandle, $dataBaseID);

print "<h1>Welcome, $profileName, to the $title</h1>";
$expDays  = $checkExp['expDays'];
$expMsgID = $checkExp['msgID'];

if ($expMsgID != ""){print "<h2>User Profile Error ($expMsgID) - Contact your System Administrator</h2>";}
elseif ($expDays > 0){print "<h2>(Password expires in $expDays days)</h2>";}

print   $hrTagAttr;
print "<div style=\"padding: 1ex 1ex 1ex 1ex;\">";
print  " Today is <span style=\"font-weight: bold;\">$sessionDateFormat </span>   </div>";

print "<div style=\"padding: 1ex 1ex 1ex 1ex;\">";
print " Welcome to your personalized information portal! <br>
    This portal is your gateway to information in your HarrisData system. <br>
    On the left, you'll find links to information you are authorized to access throughout the system. <br>
    Just point, click, and explore! <br>
  </div>";

print "<div style=\"padding: 1ex 1ex 1ex 1ex;\">";
print " The look and feel of the HarrisData EIP can be easily customized using simple web techniques.<br>
    Contact <a href=\"http://www.harrisdata.com/cusHotline.htm\" title=\"HarrisData Online\">HarrisData Support</a> for more details. <br>
  </div>";

print  $hrTagAttr;
require_once 'Copyright.php';
?>